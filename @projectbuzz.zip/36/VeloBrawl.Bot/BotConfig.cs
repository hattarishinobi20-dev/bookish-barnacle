using Newtonsoft.Json;

namespace VeloBrawl.Bot;

public class BotConfig
{
    [JsonProperty("enabled")] public bool Enabled { get; set; } = false;
    [JsonProperty("token")] public string Token { get; set; } = "idk";
    [JsonProperty("bot_username")] public string BotUsername { get; set; } = "YourUsernameBot";
    [JsonProperty("admin_ids")] public List<long> AdminIds { get; set; } = new();

    public static BotConfig LoadFromFile(string path)
    {
        if (!File.Exists(path))
        {
            var def = new BotConfig();
            File.WriteAllText(path, JsonConvert.SerializeObject(def, Formatting.Indented));
            return def;
        }
        return JsonConvert.DeserializeObject<BotConfig>(File.ReadAllText(path))!;
    }
}
