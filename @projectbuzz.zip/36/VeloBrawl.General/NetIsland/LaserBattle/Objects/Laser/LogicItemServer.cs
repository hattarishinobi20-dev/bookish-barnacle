using VeloBrawl.Supercell.Titan.CommonUtils.Utils;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.Mathematical;
using VeloBrawl.Titan.Mathematical.Data;
using VeloBrawl.Titan.Utilities;
using VeloBrawl.Tools.LaserCsv;
using VeloBrawl.Tools.LaserCsv.Manufacturer.Laser;

namespace VeloBrawl.General.NetIsland.LaserBattle.Objects.Laser;

public class LogicItemServer : LogicGameObjectServer
{
    private readonly LogicBattleModeServer _logicBattleModeServer;
    private readonly LogicItemData _logicItemData;
    private int _gameModeVariation;
    private bool _isPicked;
    private LogicCharacterServer _pickerUp = null!;
    private int _pickTicks;
    private int _ticks;
    private int _orbSpawnNextTick;

    public LogicItemServer(LogicBattleModeServer logicBattleModeServer, int classId, int instanceId, int index) :
        base(logicBattleModeServer, classId, instanceId, 0, index)
    {
        _logicBattleModeServer = logicBattleModeServer;
        _pickTicks = 0;
        _ticks = 0;
        _isPicked = false;
        _gameModeVariation = LogicDataTables.GetGameModeVariationByName(
            ((LogicLocationData)LogicDataTables.GetDataById(_logicBattleModeServer.GetLocation() < 1000000
                ? GlobalId.CreateGlobalId(CsvHelperTable.Locations.GetId(), _logicBattleModeServer.GetLocation())
                : _logicBattleModeServer.GetLocation())).GetGameModeVariation()).GetVariation();
        _logicItemData = (LogicItemData)LogicDataTables.GetDataById(GlobalId.CreateGlobalId(classId, instanceId));
        _orbSpawnNextTick = 40;
    }

    public override void Tick()
    {
        _ticks++;

        if (_logicItemData.GetName() == "OrbSpawner")
        {
            if (_ticks >= _orbSpawnNextTick)
            {
                SpawnOrbPoint();
                _orbSpawnNextTick = _ticks + 140;
            }
            return;
        }

        if (_logicItemData.GetValue() != 0)
            switch (_ticks - 40)
            {
                case <= 10 and >= 1:
                {
                    SetPosition(GetX() - 1, GetY() + -1, GetZ() + (_ticks - 40) * 2);
                    break;
                }
                case <= 20 and > 12:
                {
                    SetPosition(GetX() + 1, GetY() - -1, GetZ() - (_ticks - 40) * 2);
                    SetPosition(GetX(), GetY(), GetZ() <= 16 ? 0 : GetZ());
                    break;
                }
            }

        if (_ticks - 40 > 40) _ticks = 0;

        if (!_isPicked)
        {
            CheckPickup();
            return;
        }

        _pickTicks++;
        SetPosition(GetX(), GetY(), GetZ() + 120 / 3);

        if (_pickTicks != 3) return;

        ApplyItemEffect();
        GetLogicGameObjectManager().RemoveGameObjectReferences(this);
    }

    private void SpawnOrbPoint()
    {
        try
        {
            var pointData = LogicDataTables.GetItemByName("Point");
            var orb = new LogicItemServer(_logicBattleModeServer,
                pointData.GetClassId(), pointData.GetInstanceId(), 0);

            var rng = new System.Random(_logicBattleModeServer.GetTicksGone() + _ticks);
            var dist = rng.Next(300, 601);
            var angle = rng.Next(0, 360);

            var nx = LogicMath.Clamp(GetX() + LogicMath.GetRotatedX(dist, 0, angle), 150, 65385);
            var ny = LogicMath.Clamp(GetY() + LogicMath.GetRotatedY(dist, 0, angle), 150, 65385);

            orb.SetPosition(nx, ny, 0);
            GetLogicGameObjectManager().AddLogicGameObject(orb);
        }
        catch { }
    }

    private void CheckPickup()
    {
        const int pickRadius = 250;

        foreach (var obj in GetLogicGameObjectManager().GetNumGameObjects())
        {
            if (obj is not LogicCharacterServer hero) continue;
            if (!hero.GetCharacterData().IsHero()) continue;
            if (hero.GetPlayer() == null) continue;

            var dist2 = LogicGamePlayUtil.GetDistanceSquaredBetween(
                GetX(), GetY(), hero.GetX(), hero.GetY());

            if (dist2 > pickRadius * pickRadius) continue;

            SetPickedUpBy(hero);
            return;
        }
    }

    private void ApplyItemEffect()
    {
        if (_pickerUp == null) return;
        var player = _pickerUp.GetPlayer();
        if (player == null) return;

        switch (_logicItemData.GetName())
        {
            case "Point":
                player.ItemCount++;
                break;
            case "Money":
                player.ItemCount++;
                player.HasStar = true;
                break;
        }
    }

    public LogicItemData GetItemData() => _logicItemData;

    public void SetPickedUpBy(LogicCharacterServer logicCharacterServer)
    {
        _pickerUp = logicCharacterServer;
        _isPicked = true;
    }

    public override void Encode(BitStream bitStream, bool isOwnObject, int visionIndex, int visionTeam)
    {
        base.Encode(bitStream, isOwnObject, visionIndex, visionTeam);

        if (_logicItemData.GetInstanceId() == 5 || _logicItemData.GetInstanceId() == 24)
        {
            bitStream.WritePositiveIntMax16383(170);
            bitStream.WritePositiveIntMax16383(30);

            if (_logicItemData.GetInstanceId() == 24) bitStream.WritePositiveIntMax16383(0);
        }
        else
        {
            var v7 = _logicItemData.GetInstanceId();

            if (v7 <= 0x19 && ((1 << v7) & 0x2005040) != 0)
            {
                bitStream.WritePositiveIntMax63(0);
                bitStream.WritePositiveIntMax63(0);
            }
            else
            {
                if ((v7 & 0xFFFFFFF8) != 16) return;
                bitStream.WritePositiveIntMax3(0);
                bitStream.WritePositiveIntMax63(0);
            }
        }
    }

    public override int GetType() => ObjectTypeHelperTable.Item.GetObjectType();
}
