using VeloBrawl.General.NetIsland.LaserBattle.Objects.Laser;

namespace VeloBrawl.General.NetIsland.LaserBattle.Significant;

public class LogicPoisonServer(int a1, int a2, int a3)
{
    public int PoisonType  { get; } = a1;
    public int PoisonTileX { get; } = a2;
    public int PoisonTileY { get; } = a3;

    private int _damage;
    private int _normalDmg;
    private int _tickTimer;
    private int _secondTimer;
    private bool _isUlti;
    private LogicCharacterServer? _source;
    private int _sourceIndex;

    public void Setup(int damage, int normalDmg, bool isUlti, LogicCharacterServer source, int sourceIndex)
    {
        var ticks    = GetTickCount(PoisonType);
        _damage      = damage / ticks;
        _normalDmg   = normalDmg / ticks;
        _isUlti      = isUlti;
        _source      = source;
        _sourceIndex = sourceIndex;
        _tickTimer   = 20;
        _secondTimer = ticks;
    }

    public void Refresh(int damage, int normalDmg, bool isUlti)
    {
        var ticks    = GetTickCount(PoisonType);
        _damage      = damage / ticks;
        _normalDmg   = normalDmg / ticks;
        _isUlti      = isUlti;
        _tickTimer   = 20;
        _secondTimer = ticks;
    }

    public void Tick(LogicBattleModeServer logicBattleModeServer)
    {
        if (_source == null) return;
        _tickTimer--;
        if (_tickTimer > 0) return;
        _source.TakeDamage(_damage);
        _secondTimer--;
        _tickTimer = 20;
    }

    public int GetTickCount(int type) => type == 4 ? 2 : 4;

    public bool AllowStacking(int type) => type == 4;
}
