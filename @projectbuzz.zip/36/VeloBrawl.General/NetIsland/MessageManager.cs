using System.Linq;
using System.Net.Sockets;
using VeloBrawl.General.Cloud;
using VeloBrawl.General.GHelp;
using VeloBrawl.General.NetIsland.LaserBattle;
using VeloBrawl.General.Networking;
using VeloBrawl.Logic.Database;
using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Logic.Database.Alliance;
using VeloBrawl.Logic.Environment.LaserCommand.Laser;
using VeloBrawl.Logic.Environment.LaserListener;
using VeloBrawl.Logic.Environment.LaserMessage;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_1;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_11;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_27;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_4;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Alliance;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Player;
using VeloBrawl.Logic.Environment.LaserNotification;
using VeloBrawl.Logic.Environment.LaserNotification.Laser;
using VeloBrawl.StaticService.Laser;
using VeloBrawl.Supercell.Titan.CommonUtils;
using VeloBrawl.Supercell.Titan.CommonUtils.Utils;
using VeloBrawl.Titan.Mathematical.Data;
using VeloBrawl.Titan.Utilities;
using VeloBrawl.Tools.LaserCsv;
using VeloBrawl.Tools.LaserCsv.Manufacturer.Laser;
using VeloBrawl.Tools.LaserData;
using VeloBrawl.Tools.LaserFactory;

namespace VeloBrawl.General.NetIsland;

public class MessageManager(
    Socket? listener,
    Socket? userListener,
    Connection? connection,
    ServerConnection? serverConnection)
{
    private readonly LogicHomeMode _logicHomeMode = new();
    public readonly Dictionary<int, PiranhaMessage> ToProxyMessageDictionary = new();
    private int _joinedTime;
    private System.Timers.Timer? _lobbyInfoTimer;
    private LanguageFactory _languageFactory = LanguageFactory.English;
    private long _lastKeepAliveReceivedTime = LogicTimeUtil.GetTimestamp();
    private Socket? _listener = listener;
    private int _ping = 100;
    private int _playerGeoEventSlot;
    private int _playerStatus;
    public int ToProxyMessageSeed = 300;

    public void SendMessage(PiranhaMessage? piranhaMessage)
    {
        if (piranhaMessage!.IsServerToClientMessage()) serverConnection!.GetMessaging()!.Send(piranhaMessage);
    }

    public bool IsActive()
    {
        if (_playerGeoEventSlot < 0 || LogicTimeUtil.GetTimestamp() - _lastKeepAliveReceivedTime < 6 * 5)
            return LogicTimeUtil.GetTimestamp() - _lastKeepAliveReceivedTime < 6 * 5;

        IdentifierListener.RemoveLogicGameListenerByAccountId(serverConnection!.GetAccountModel().GetAccountId());

        Saver.OwnMatchmakingManager.MatchmakingManagers[_playerGeoEventSlot]
            .RemovePlayerFromMassive(serverConnection!.GetAccountModel().GetAccountId(), true);
        {
            _playerGeoEventSlot = -1;
        }

        serverConnection!.GetAccountModel()
            .SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.PlayerStatus, 0);

        return LogicTimeUtil.GetTimestamp() - _lastKeepAliveReceivedTime < 6 * 5;
    }

    public int GetPing()
    {
        return _ping;
    }

    public int ConstructInstance(PiranhaMessage piranhaMessage)
    {
        ToProxyMessageSeed++;
        ToProxyMessageDictionary.TryAdd(ToProxyMessageSeed, piranhaMessage);

        return ToProxyMessageSeed;
    }

    public int ReceiveMessage(PiranhaMessage? piranhaMessage)
    {
        if (!piranhaMessage!.IsClientToServerMessage()) return 0;

        if (serverConnection!.GetAccountModel() == null!)
            return piranhaMessage.GetMessageType() switch
            {
                10101 => LoginMessageReceived((LoginMessage)piranhaMessage),
                10108 => KeepAliveMessageReceived((KeepAliveMessage)piranhaMessage),
                _ => 0
            };

        if (IsActive())
            switch (piranhaMessage.GetMessageType())
            {
                case 30000:
                    return AttributionMessageReceived((AttributionMessage)piranhaMessage);
            }

        if (!(bool)
            serverConnection.GetAccountModel().GetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.UserIsAuthed))
            return 0;

        if (!(bool)serverConnection.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.UserIsAuthed) &&
            Convert.ToInt32(
                serverConnection.GetAccountModel().GetFieldValueByAccountStructureParameterFromAccountModel(
                    AccountStructure
                        .PlayerAge)) < 3)
            return 0;

        KeepAliveMessageReceived(null!);

        return piranhaMessage.GetMessageType() switch
        {
            10101 => LoginMessageReceived((LoginMessage)piranhaMessage),
            10108 => KeepAliveMessageReceived((KeepAliveMessage)piranhaMessage),
            14103 => MatchmakeRequestMessageReceived((MatchmakeRequestMessage)piranhaMessage),
            10177 => ClientInfoMessageReceived((ClientInfoMessage)piranhaMessage),
            10111 => AccountIdentifiersMessageReceived((AccountIdentifiersMessage)piranhaMessage),
            10107 => ClientCapabilitiesMessageReceived((ClientCapabilitiesMessage)piranhaMessage),
            10110 => AnalyticEventMessageReceived((AnalyticEventMessage)piranhaMessage),
            14106 => CancelMatchmakingMessageReceived((CancelMatchmakingMessage)piranhaMessage),
            14166 => ChronosEventSeenMessageReceived((ChronosEventSeenMessage)piranhaMessage),
            14102 => EndClientTurnMessageReceived((EndClientTurnMessage)piranhaMessage),
            14109 => GoHomeFromOfflinePractiseMessageReceived((GoHomeFromOfflinePractiseMessage)piranhaMessage),
            14101 => GoHomeMessageReceived((GoHomeMessage)piranhaMessage),
            14366 => PlayerStatusMessageReceived((PlayerStatusMessage)piranhaMessage),
            10555 => ClientInputMessageReceived((ClientInputMessage)piranhaMessage),
            10212 => ChangeAvatarNameMessageReceived((ChangeAvatarNameMessage)piranhaMessage),
            14301 => CreateAllianceMessageReceived((CreateAllianceMessage)piranhaMessage),
            14302 => AskForAllianceDataMessageReceived((AskForAllianceDataMessage)piranhaMessage),
            14316 => ChangeAllianceSettingsMessageReceived((ChangeAllianceSettingsMessage)piranhaMessage),
            14308 => LeaveAllianceMessageReceived((LeaveAllianceMessage)piranhaMessage),
            30000 => AttributionMessageReceived((AttributionMessage)piranhaMessage),
            14113 => GetPlayerProfileMessageReceived((GetPlayerProfileMessage)piranhaMessage),
            14403 => GetLeaderboardMessageReceived((GetLeaderboardMessage)piranhaMessage),
            14600 => AvatarNameCheckRequestMessageReceived((AvatarNameCheckRequestMessage)piranhaMessage),
            14118 => SinglePlayerMatchRequestMessageReceived((SinglePlayerMatchRequestMessage)piranhaMessage),
            14303 => AskForJoinableAlliancesListMessageReceived((AskForJoinableAlliancesListMessage)piranhaMessage),
            14324 => AskForJoinableAlliancesListMessageReceived((AskForJoinableAlliancesListMessage)piranhaMessage),
            14110 => AskForBattleEndMessageReceived((AskForBattleEndMessage)piranhaMessage),
            _ => 0
        };
    }

    private int SinglePlayerMatchRequestMessageReceived(SinglePlayerMatchRequestMessage piranhaMessage)
    {
        var location = 15000000 + 121;

        var players = new Dictionary<long, ServerConnection>
            { { serverConnection!.GetAccountModel().GetAccountId(), serverConnection } };

        var gameModeVariation = LogicDataTables.GetGameModeVariationByName
            (((LogicLocationData)LogicDataTables.GetDataById(location)).GetGameModeVariation()).GetVariation();

        var logicPlayerMap = new List<LogicPlayer>();
        var logicPlayerMapWithBots = new List<LogicPlayer>();
        var logicPlayerDictionary = new Dictionary<LogicPlayer, ServerConnection>();

        var logicBattleModeServer =
            new LogicBattleModeServer(Saver.UdpInfoPorts[new Random().Next(0, Saver.UdpInfoPorts.Count - 1)],
                true);
        {
            logicBattleModeServer.SetLocation(location);
            logicBattleModeServer.GenerateTileMap();
            logicBattleModeServer.SetUpdateTick(20);
            logicBattleModeServer.UpdateTime();
        }

        var i = 0;
        foreach (var player in players) // player-part.
        {
            if (!InteractiveModule.UdpSessionIdsMassive.ContainsKey(player.Value.GetAccountModel().GetAccountId()))
                InteractiveModule.UdpSessionIdsMassive.Add(player.Value.GetAccountModel().GetAccountId(),
                    ++Saver.LastUdpSessionId);
            else
                InteractiveModule.UdpSessionIdsMassive[player.Value.GetAccountModel().GetAccountId()] =
                    ++Saver.LastUdpSessionId;

            var playerDisplayData = new PlayerDisplayData();
            {
                playerDisplayData.SetAvatarName(player.Value.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AvatarName)
                    .ToString()!);
                playerDisplayData.SetPlayerThumbnail(Convert.ToInt32(player.Value.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure
                        .PlayerThumbnailGlobalId)));
                playerDisplayData.SetNameColor(Convert.ToInt32(player.Value.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.NameColorGlobalId)));
            }

            var logicPlayer = new LogicPlayer();
            {
                logicPlayer.SetPlayerIndex(i);
                logicPlayer.SetTeamIndex(i % 2);
                logicPlayer.SetBounty(gameModeVariation == 3);
                logicPlayer.SetAccountModel(player.Value.GetAccountModel());
                logicPlayer.SetPlayerDisplayData(playerDisplayData);
                logicPlayer.SessionId =
                    InteractiveModule.UdpSessionIdsMassive[player.Value.GetAccountModel().GetAccountId()] - 0;

                logicPlayer.HeroInfo.Add(GlobalId.GetInstanceId(piranhaMessage.CharacterId));
                logicPlayer.HeroInfo.Add(11);
                logicPlayer.HeroInfo.Add(0);
                logicPlayer.HeroInfo.Add(GlobalId.GetInstanceId(piranhaMessage.SkinId));
            }

            logicPlayerMapWithBots.Add(logicPlayer);
            logicPlayerMap.Add(logicPlayer);
            logicPlayerDictionary.Add(logicPlayer, player.Value);
            logicBattleModeServer.AddPlayer(logicPlayer, player.Value);
            var oldSessionId = InteractiveModule.UdpSessionIdsMassive.GetValueOrDefault(
    player.Value.GetAccountModel().GetAccountId(), -1);
            if (oldSessionId > 0)
                InteractiveModule.LogicBattleModeServersMassive!.Remove(oldSessionId);
            InteractiveModule.LogicBattleModeServersMassive!.TryAdd(logicPlayer.SessionId, logicBattleModeServer);
            i++;
        }

        logicBattleModeServer.TickUpdate();

        foreach (var player in logicPlayerMap)
        {
            var startLoading = new StartLoadingMessage();
            {
                startLoading.SetLocation(location);
                startLoading.SetGameModeVariation(LogicGameModeUtil.HasTwoTeams(LogicDataTables
                    .GetGameModeVariationByName
                        (((LogicLocationData)LogicDataTables.GetDataById(location)).GetGameModeVariation())
                    .GetVariation())
                    ? 1
                    : 6);
                startLoading.SetLogicPlayer(player);
                startLoading.SetLogicPlayerMap(logicPlayerMapWithBots);
                startLoading.SetIsSpectate(false);
                startLoading.SetIsFriendlyMatch(false);
                startLoading.SetIsUnderdog(false);
            }

            logicPlayerDictionary[player].GetMessaging()!.Send(startLoading);
            logicPlayerDictionary[player].GetMessaging()!.Send(
                new UdpConnectionInfoMessage(
                    Saver.UdpInfoPorts[0],
                    Saver.UdpInfoDomain,
                    player.SessionId));
        }

        return 1;
    }

    private int AttributionMessageReceived(AttributionMessage piranhaMessage)
    {
        if (!piranhaMessage.StringReferenceOpenList[9].Equals("utm_source=google-play&utm_medium=organic")) return 0;
        if (!piranhaMessage.StringReferenceOpenList[3]
                .Equals($"{Fingerprint.GetMajorVersion()}.{Fingerprint.GetMinorVersion()}")) return 0;
        if (!piranhaMessage.StringReferenceOpenList[0].Contains("Mozilla")) return 0;
        if (!piranhaMessage.StringReferenceOpenList[0].Contains("Linux")) return 0;
        if (!piranhaMessage.StringReferenceOpenList[0].Contains("Android")) return 0;

        serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
            AccountStructure.UserIsAuthed, true);

        return 1;
    }

    private int LeaveAllianceMessageReceived(LeaveAllianceMessage piranhaMessage)
    {
        AllianceResponseMessage? allianceResponseMessage;

        var v1 = (long)serverConnection!.GetAccountModel()
            .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId);

        if (v1 < 1)
        {
            allianceResponseMessage = new AllianceResponseMessage();
            {
                allianceResponseMessage.IsResponse(94);
            }

            SendMessage(allianceResponseMessage);
            return 0;
        }

        var v2 = Databases.AllianceDatabase.LoadAlliance(v1);
        {
            var d1 =
                (Dictionary<long, AllianceMemberEntry>)v2.GetFieldValueByAllianceStructureParameterFromAllianceModel(
                    AllianceStructure.AllianceMemberEntryList);
            {
                d1.Remove(serverConnection!.GetAccountModel().GetAccountId());
            }

            v2.SetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceMemberEntryList,
                d1);
        }

        serverConnection.GetAccountModel()
            .SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId, (long)0);

        allianceResponseMessage = new AllianceResponseMessage();
        {
            allianceResponseMessage.IsResponse(80);
        }

        SendMessage(allianceResponseMessage);
        SendMessage(new MyAllianceMessage());

        var allianceModel = Databases.AllianceDatabase.LoadAlliance(97);
        var allianceMemberEntry = new AllianceMemberEntry
        {
            AccountId = serverConnection.GetAccountModel().GetAccountId(),
            AllianceRoleHelperTable = AllianceRoleHelperTable.Member
        };

        serverConnection!.GetAccountModel()
            .SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId,
                allianceModel.GetAllianceId());
        serverConnection.GetAccountModel()
            .SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceMemberEntry,
                allianceMemberEntry);

        var c = (Dictionary<long, AllianceMemberEntry>)
            allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(
                AllianceStructure.AllianceMemberEntryList);
        c.Add(serverConnection.GetAccountModel().GetAccountId(), allianceMemberEntry);

        allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
            AllianceStructure.AllianceMemberEntryList, c);

        ToSendAutomizeHelper.SendAllianceStatus(
            Databases.AllianceDatabase.LoadAlliance(
                Convert.ToInt64(serverConnection!.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.AllianceId))), serverConnection!.GetAccountModel().GetAccountId());
        return 1;
    }

    private int ChangeAllianceSettingsMessageReceived(ChangeAllianceSettingsMessage piranhaMessage)
    {
        AllianceResponseMessage? allianceResponseMessage;

        if (Databases.AllianceDatabase.LoadAlliance((long)serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId)) ==
            null!)
        {
            allianceResponseMessage = new AllianceResponseMessage();
            {
                allianceResponseMessage.IsResponse(93);
            }

            SendMessage(allianceResponseMessage);
            return 0;
        }

        if (!LogicDataTables.GetAllianceRoleByName(((AllianceMemberEntry)serverConnection!.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceMemberEntry))
                .AllianceRoleHelperTable.GetCsvName()).GetCanChangeAllianceSettings())
        {
            allianceResponseMessage = new AllianceResponseMessage();
            {
                allianceResponseMessage.IsResponse(95);
            }

            SendMessage(allianceResponseMessage);
            return 0;
        }

        if (!Helper.GetIsAdequateString(piranhaMessage.GetAllianceDescription()))
        {
            allianceResponseMessage = new AllianceResponseMessage();
            {
                allianceResponseMessage.IsResponse(23);
            }

            SendMessage(allianceResponseMessage);
            return 1;
        }

        var allianceModel = Databases.AllianceDatabase.LoadAlliance((long)serverConnection!.GetAccountModel()
            .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId));

        allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
            AllianceStructure.AllianceDescription, piranhaMessage.GetAllianceDescription());
        allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
            AllianceStructure.AllianceBadgeData, piranhaMessage.GetAllianceBadgeData());
        allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
            AllianceStructure.AllianceRegion, piranhaMessage.GetAllianceRegion());
        allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
            AllianceStructure.AllianceType, piranhaMessage.GetAllianceType());
        allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
            AllianceStructure.AllianceRequiredScore, piranhaMessage.GetRequiredScore());
        allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
            AllianceStructure.AllianceFamilyType, piranhaMessage.GetIsFamilyType());

        allianceResponseMessage = new AllianceResponseMessage();
        {
            allianceResponseMessage.IsResponse(10);
        }

        SendMessage(allianceResponseMessage);

        ToSendAutomizeHelper.SendMyAlliance(this,
            Databases.AllianceDatabase.LoadAlliance((long)serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId)),
            serverConnection!.GetAccountModel(), true);

        ToSendAutomizeHelper.SendAllianceStatus(
            Databases.AllianceDatabase.LoadAlliance(
                Convert.ToInt64(serverConnection!.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.AllianceId))), serverConnection!.GetAccountModel().GetAccountId());

        return 1;
    }

    private int AskForAllianceDataMessageReceived(AskForAllianceDataMessage piranhaMessage)
    {
        if (Databases.AllianceDatabase.LoadAlliance(piranhaMessage.GetAllianceId()) == null!)
            return 0;

        ToSendAutomizeHelper.SendAllianceStatus(
            Databases.AllianceDatabase.LoadAlliance(
                Convert.ToInt64(serverConnection!.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.AllianceId))), serverConnection!.GetAccountModel().GetAccountId());

        ToSendAutomizeHelper.SendAllianceData(this,
            Databases.AllianceDatabase.LoadAlliance(piranhaMessage.GetAllianceId()),
            (long)serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId),
            myAccountId: serverConnection.GetAccountModel().GetAccountId());

        ToSendAutomizeHelper.SendAllianceStatus(
            Databases.AllianceDatabase.LoadAlliance(
                Convert.ToInt64(serverConnection!.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.AllianceId))), serverConnection!.GetAccountModel().GetAccountId());

        return 1;
    }

    private int CreateAllianceMessageReceived(CreateAllianceMessage piranhaMessage)
    {
        AllianceResponseMessage? allianceResponseMessage;

        if (Convert.ToInt32(serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId)) > 0)
        {
            allianceResponseMessage = new AllianceResponseMessage();
            {
                allianceResponseMessage.IsResponse(21);
            }

            SendMessage(allianceResponseMessage);
            return 0;
        }

        if (Convert.ToInt32(serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(
                    AccountStructure.LastCreateAllianceTime)) > 1 * 60 * 60 &&
            LogicTimeUtil.GetTimestamp() - Convert.ToInt32(serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(
                    AccountStructure.LastCreateAllianceTime)) < 1 * 60 * 60)
        {
            allianceResponseMessage = new AllianceResponseMessage();
            {
                allianceResponseMessage.IsResponse(21);
            }

            SendMessage(allianceResponseMessage);
            return 0;
        }

        if (Helper.GetIsAdequateString(piranhaMessage.AllianceName) &&
            Helper.GetIsCorrectName(piranhaMessage.AllianceName))
        {
            if (Helper.GetIsAdequateString(piranhaMessage.AllianceDescription))
            {
                var allianceMemberEntry = new AllianceMemberEntry
                {
                    AccountId = serverConnection.GetAccountModel().GetAccountId(),
                    AllianceRoleHelperTable = AllianceRoleHelperTable.Leader
                };

                var allianceMemberList = new Dictionary<long, AllianceMemberEntry>();
                {
                    allianceMemberList.Add(serverConnection.GetAccountModel().GetAccountId(), allianceMemberEntry);
                }

                var allianceModel = Databases.AllianceDatabase.CreateAlliance(new AllianceModel());
                {
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceCreatedDate,
                        $"{DateTime.Now:yyyy/MM/dd-(dddd) HH:mm:ss}");
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceName, piranhaMessage.AllianceName);
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceDescription, piranhaMessage.AllianceDescription);
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceBadgeData, piranhaMessage.GetAllianceBadgeData());
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceRegion, piranhaMessage.AllianceRegion);
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceType, piranhaMessage.GetAllianceType());
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceRequiredScore, piranhaMessage.GetRequiredScore());
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceFamilyType, piranhaMessage.IsFamilyType);
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceMemberEntryList, allianceMemberList);
                    allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(
                        AllianceStructure.AllianceLanguage, 1000000);
                }

                serverConnection!.GetAccountModel()
                    .SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId,
                        allianceModel.GetAllianceId());
                serverConnection.GetAccountModel()
                    .SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceMemberEntry,
                        allianceMemberEntry);
                serverConnection.GetAccountModel()
                    .SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.LastCreateAllianceTime,
                        LogicTimeUtil.GetTimestamp());

                var allianceHeaderEntry = new AllianceHeaderEntry();
                {
                    allianceHeaderEntry.SetAllianceId(allianceModel.GetAllianceId());
                    allianceHeaderEntry.SetAllianceName(allianceModel
                        .GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceName)
                        .ToString()!);
                    allianceHeaderEntry.SetScore(allianceMemberList.Sum(member =>
                        Convert.ToInt32(Databases.AccountDatabase.LoadAccount(member.Value.AccountId)
                            .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.Trophies))));
                    allianceHeaderEntry.SetAllianceType(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceType)));
                    allianceHeaderEntry.SetAllianceBadgeData(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceBadgeData)));
                    allianceHeaderEntry.SetRequiredScore(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceRequiredScore)));
                    allianceHeaderEntry.SetPreferredLanguage(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceLanguage)));
                    allianceHeaderEntry.SetAllianceRegionData(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceRegion)));
                    allianceHeaderEntry.SetNumberOfMembers(allianceMemberList.Count);
                    allianceHeaderEntry.SetIsFamilyType(
                        (bool)allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceFamilyType));
                }

                var allianceFullEntry = new AllianceFullEntry();
                {
                    allianceFullEntry.SetAllianceDescription(allianceModel
                        .GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceDescription).ToString()!);
                    allianceFullEntry.SetAllianceHeaderEntry(allianceHeaderEntry);
                    allianceFullEntry.SetAllianceMembers(allianceMemberList);
                }

                var allianceDataMessage = new AllianceDataMessage();
                {
                    allianceDataMessage.IsMyAlliance = true;
                    allianceDataMessage.SetAllianceFullEntry(allianceFullEntry);
                }

                var myAllianceMessage = new MyAllianceMessage();
                {
                    myAllianceMessage.OnlineMembers = allianceMemberList.Count(keyValuePair =>
                        IdentifierListener.GetV2LogicGameListenerByAccountId(keyValuePair.Key));
                    myAllianceMessage.AllianceRole = allianceMemberEntry.AllianceRoleHelperTable;
                    myAllianceMessage.AllianceHeaderEntry = allianceHeaderEntry;
                }

                allianceResponseMessage = new AllianceResponseMessage();
                {
                    allianceResponseMessage.IsResponse(20);
                }

                SendMessage(allianceResponseMessage);
                SendMessage(myAllianceMessage);
                SendMessage(allianceDataMessage);
                return 1;
            }

            allianceResponseMessage = new AllianceResponseMessage();
            {
                allianceResponseMessage.IsResponse(23);
            }

            SendMessage(allianceResponseMessage);
            return 1;
        }

        allianceResponseMessage = new AllianceResponseMessage();
        {
            allianceResponseMessage.IsResponse(piranhaMessage.AllianceName.Length < 3 ? 24 : 22);
        }

        SendMessage(allianceResponseMessage);
        return 1;
    }

    private int ChangeAvatarNameMessageReceived(ChangeAvatarNameMessage piranhaMessage)
    {
        if (piranhaMessage.GetNameSetByUser()) return 0;

        if (Helper.GetIsAdequateString(piranhaMessage.GetName()) &&
            Helper.GetIsCorrectName(piranhaMessage.GetName()))
        {
            serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.NameSetByUser,
                !piranhaMessage.GetNameSetByUser());

            serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.AvatarName,
                piranhaMessage.GetName());

            var availableServerCommandMessage = new AvailableServerCommandMessage();
            {
                availableServerCommandMessage.SetServerCommand(new LogicChangeAvatarNameCommand(
                    piranhaMessage.GetName(), 0));
            }

            SendMessage(availableServerCommandMessage);
        }
        else
        {
            var avatarNameChangeFailed = new AvatarNameChangeFailedMessage();
            {
                avatarNameChangeFailed.SetReason(piranhaMessage.GetName().Length < 3 ? 2 :
                    piranhaMessage.GetName().Length >= 15 ? 1 : 0);
            }

            SendMessage(avatarNameChangeFailed);
        }

        return 1;
    }

    private int AvatarNameCheckRequestMessageReceived(AvatarNameCheckRequestMessage piranhaMessage)
    {
        var name = piranhaMessage.GetName();
    
        if (Helper.GetIsAdequateString(name) && Helper.GetIsCorrectName(name))
        {
            serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.AvatarName, name);
            serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.NameSetByUser, true);
    
            var availableServerCommandMessage = new AvailableServerCommandMessage();
            availableServerCommandMessage.SetServerCommand(new LogicChangeAvatarNameCommand(name, 0));
            SendMessage(availableServerCommandMessage);
        }
        else
        {
            var failed = new AvatarNameChangeFailedMessage();
            failed.SetReason(name.Length < 3 ? 2 : name.Length >= 15 ? 1 : 0);
            SendMessage(failed);
        }
    
        return 1;
    }

    private int EndClientTurnMessageReceived(EndClientTurnMessage piranhaMessage)
    {
        _logicHomeMode.EndClientTurnReceived(piranhaMessage.GetTick(), piranhaMessage.GetChecksum(),
            piranhaMessage.GetCommands());

        return 1;
    }

    private int ChronosEventSeenMessageReceived(ChronosEventSeenMessage piranhaMessage)
    {
        // ignored.
        return 0;
    }

    private int GoHomeFromOfflinePractiseMessageReceived(GoHomeFromOfflinePractiseMessage piranhaMessage)
    {
        ConstructInstance(new OwnHomeDataMessage(serverConnection!.GetAccountModel()));
        return 1;
    }

    private int GoHomeMessageReceived(GoHomeMessage piranhaMessage)
    {
        if (_playerGeoEventSlot >= 0)
        {
            Saver.OwnMatchmakingManager.MatchmakingManagers[_playerGeoEventSlot]
                .RemovePlayerFromMassive(serverConnection!.GetAccountModel().GetAccountId(), true);
            _playerGeoEventSlot = -1;
        }
    
        var accountId = serverConnection!.GetAccountModel().GetAccountId();
        if (InteractiveModule.UdpSessionIdsMassive.TryGetValue(accountId, out var sessionId))
        {
            InteractiveModule.LogicBattleModeServersMassive!.Remove(sessionId);
            InteractiveModule.UdpSessionIdsMassive.Remove(accountId);
        }
    
        ConstructInstance(new OwnHomeDataMessage(serverConnection!.GetAccountModel()));
        return 1;
    }

    private int AskForBattleEndMessageReceived(AskForBattleEndMessage piranhaMessage)
    {
        var accountId = serverConnection!.GetAccountModel().GetAccountId();

        LogicBattleModeServer? battle = null;
        if (InteractiveModule.UdpSessionIdsMassive.TryGetValue(accountId, out var sessionId))
        {
            InteractiveModule.LogicBattleModeServersMassive!.TryGetValue(sessionId, out battle);
            InteractiveModule.LogicBattleModeServersMassive!.Remove(sessionId);
            InteractiveModule.UdpSessionIdsMassive.Remove(accountId);
        }

        if (battle != null)
        {
            var ownPlayer = battle.LogicPlayers.FirstOrDefault(p => !p.IsBot());
            if (ownPlayer != null && !battle.BattleEnded)
            {
                battle.WinnerTeam = piranhaMessage.BattleResult == 1 ? ownPlayer.GetTeamIndex() : 1 - ownPlayer.GetTeamIndex();
                var msg = new BattleEndMessage();
                msg.Setup(
                    battle.GetGameModeVariation(),
                    piranhaMessage.BattleResult == 1 ? 1 : 2,
                    true,
                    ownPlayer,
                    battle.LogicPlayers,
                    trophiesReward: piranhaMessage.BattleResult == 1 ? 5 : 0,
                    tokensReward: 10,
                    experienceReward: 20,
                    experience: 0
                );
                serverConnection!.GetMessaging()!.Send(msg);
            }
        }

        ConstructInstance(new OwnHomeDataMessage(serverConnection!.GetAccountModel()));
        return 1;
    }

    private int PlayerStatusMessageReceived(PlayerStatusMessage piranhaMessage)
    {
        _playerStatus = piranhaMessage.GetPlayerStatus();
        {
            serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.PlayerStatus,
                _playerStatus);
        }

        ToSendAutomizeHelper.SendAllianceStatus(
            Databases.AllianceDatabase.LoadAlliance(
                Convert.ToInt64(serverConnection!.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.AllianceId))), serverConnection!.GetAccountModel().GetAccountId());

        return 1;
    }

    private int ClientInputMessageReceived(ClientInputMessage piranhaMessage)
    {
        var accountId = serverConnection!.GetAccountModel().GetAccountId();
        if (!InteractiveModule.UdpSessionIdsMassive.TryGetValue(accountId, out var sessionId)) return 1;
        if (!InteractiveModule.LogicBattleModeServersMassive!.TryGetValue(sessionId, out var battle)) return 1;

        var inputs = piranhaMessage.ClientInputManager?.GetOverrideGroup();
        if (inputs == null) return 1;

        foreach (var input in inputs)
            battle.HandleClientInput(input);

        return 1;
    }

    private int CancelMatchmakingMessageReceived(CancelMatchmakingMessage piranhaMessage)
    {
        SendMessage(new MatchMakingCancelledMessage());

        if (_playerGeoEventSlot < 0) return 0;

        Saver.OwnMatchmakingManager.MatchmakingManagers[_playerGeoEventSlot]
            .RemovePlayerFromMassive(serverConnection!.GetAccountModel().GetAccountId());
        {
            _playerGeoEventSlot = -1;
        }

        return 1;
    }

    private int AnalyticEventMessageReceived(AnalyticEventMessage piranhaMessage)
    {
        if (false)
        {
            var c2 = new AvailableServerCommandMessage();
            {
                c2.SetServerCommand(new LogicAddNotificationCommand(new FloaterTextNotification(
                    piranhaMessage.GetAnalyticEvent().GetEvent() + $" ({LogicTimeUtil.GetTimestamp()}): " +
                    piranhaMessage.GetAnalyticEvent().GetEventInfo())));
            }

            Databases.NotificationIntraSignedDatabase.GetAppendix(Convert.ToInt64(serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(
                    AccountStructure.NotificationFactoryIntraSignedId))).Create(new FloaterTextNotification(
                piranhaMessage.GetAnalyticEvent().GetEvent() + ": " +
                piranhaMessage.GetAnalyticEvent().GetEventInfo()));
        }

        return 1;
    }

    private int ClientCapabilitiesMessageReceived(ClientCapabilitiesMessage piranhaMessage)
    {
        _ping = piranhaMessage.GetPing();
        return 1;
    }

    private int AccountIdentifiersMessageReceived(AccountIdentifiersMessage piranhaMessage)
    {
        return 0;
    }

    private int ClientInfoMessageReceived(ClientInfoMessage piranhaMessage)
    {
        if (!InteractiveModule.UdpSessionIdsMassive.ContainsKey(serverConnection!.GetAccountModel().GetAccountId())) return 0;
    
        SendMessage(new UdpConnectionInfoMessage(
            Saver.UdpInfoPorts[0],
            Saver.UdpInfoDomain,
            InteractiveModule.UdpSessionIdsMassive[serverConnection.GetAccountModel().GetAccountId()]));
    
        return 1;
    }

    private int MatchmakeRequestMessageReceived(MatchmakeRequestMessage piranhaMessage)
    {
        if (!Saver.OwnMatchmakingManager.MatchmakingManagers.ContainsKey(piranhaMessage.GetEventSlot()))
        {
            var failed = new MatchmakeFailedMessage();
            failed.SetErrorCode(19);
            SendMessage(failed);
            return 1;
        }

        var v1 = Saver.OwnMatchmakingManager.MatchmakingManagers[piranhaMessage.GetEventSlot()]
            .AddPlayerToMassive(serverConnection!.GetAccountModel().GetAccountId(), serverConnection); 
        {
            if (v1)
            {
                _playerGeoEventSlot = piranhaMessage.GetEventSlot();
                return 1;
            }

            var message = new MatchmakeFailedMessage();
            {
                message.SetErrorCode(19);
            }

            SendMessage(message);
        }

        return 1;
    }

    private int KeepAliveMessageReceived(KeepAliveMessage piranhaMessage)
    {
        if (piranhaMessage != null!) _lastKeepAliveReceivedTime = LogicTimeUtil.GetTimestamp();
        else _lastKeepAliveReceivedTime = LogicTimeUtil.GetTimestamp() - 5;

        if (piranhaMessage == null!) return 1;

        SendMessage(new KeepAliveServerMessage());

        serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
            AccountStructure.LastOnlineTime,
            LogicTimeUtil.GetTimestamp());

        serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
            AccountStructure.PlayTimeSeconds,
            Convert.ToInt32(serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.PlayTimeSeconds)) +
            6 * 4);

        return 1;
    }

    private int LoginMessageReceived(LoginMessage piranhaMessage)
    {
        var accountModel = new AccountModel();
        var plIns = GlobalId.GetInstanceId(piranhaMessage.GetPreferredLanguage());

        int accountLvl;
        {
            accountLvl = piranhaMessage.GetAccountId() == 0
                ? 1 // need to create
                : 2; // account created (local usage)

            if (accountLvl == 2)
                try
                {
                    var loadedAccount = Databases.AccountDatabase.LoadAccount(piranhaMessage.GetAccountId());
                    if (loadedAccount == null!)
                        accountLvl = 3;
                    else
                        accountLvl = piranhaMessage.GetPassToken() ==
                                     loadedAccount.GetFieldValueByAccountStructureParameterFromAccountModel(
                                         AccountStructure.PassToken).ToString()
                            ? 4
                            : 3;
                }
                catch (Exception)
                {
                    accountLvl = 3;
                }
        }

        switch (accountLvl)
        {
            case 1:
            {
                var notificationFactory = new NotificationFactory();
                {
                    notificationFactory.AccountModel = accountModel;
                }

                accountModel = Databases.AccountDatabase.CreateAccount(accountModel);
                notificationFactory.AccountModel = accountModel;
                {
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.HomeId,
                        Helper.GenerateRandomIntForBetween(1, 10));
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.PassToken,
                        Helper.GenerateToken(accountModel.GetAccountId()));
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AvatarName,
                        "Brawler");
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.TrophyRoadProgress,
                        999);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.Trophies,
                        50000);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.MaxTrophies,
                        50000);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.PlayerThumbnailGlobalId,
                        GlobalId.CreateGlobalId(CsvHelperTable.PlayerThumbnails.GetId(), 0));
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.NameColorGlobalId,
                        GlobalId.CreateGlobalId(CsvHelperTable.NameColors.GetId(), 0));
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.SessionCount,
                        Convert.ToInt32(accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(
                            AccountStructure
                                .SessionCount)) + 1);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.LogicOfferBundleList,
                        new List<LogicOfferBundle>());
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.AccountCreatedDate,
                        $"{DateTime.Now:yyyy/MM/dd-(dddd) HH:mm:ss}");
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.StartPlayTimeSeconds,
                        LogicTimeUtil.GetTimestamp());
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.PlayTimeSeconds, 0);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.HomeBrawlerGlobalId, GlobalId.CreateGlobalId(
                            CsvHelperTable.Characters.GetId(), 47));
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.Heroes,
                        new List<int> { 0, 1, 2, 3, 4, 5, 36 }); 
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.SupportedCreator,
                        "ОБТ");
                    accountModel.Home.BrawlPassTokens = 0;
                    accountModel.Home.HasPremiumPass = false;
                    accountModel.Home.BrawlPassProgress = 0;
                    accountModel.Home.PremiumPassProgress = 0;
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.NotificationFactoryIntraSignedId,
                        accountModel.GetAccountId() * 10);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.IntValueEntryX,
                        new Dictionary<int, IntValueEntry> { { 15, new IntValueEntry(15, 1) } });
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.IntValueEntryY,
                        new Dictionary<int, IntValueEntry>
                        {
                            {
                                1, new IntValueEntry(1,
                                    GlobalId.CreateGlobalId(CsvHelperTable.Themes.GetId(), 26))
                            }
                        });                 
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.UserIsAuthed, true); 
                }
                
    

                Databases.NotificationIntraSignedDatabase.AddAppendix(Convert.ToInt64(
                    accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.NotificationFactoryIntraSignedId)), notificationFactory);

                break;
            }
            case 3:
            {
                try
                {
                    if (piranhaMessage.GetAccountId() < 0)
                    {
                        userListener!.Close();
                    }
                    else
                    {
                        var loginFailedMessage = new LoginFailedMessage();
                        {
                            loginFailedMessage.SetErrorCode(Convert.ToInt32(ErrorCodeHelperTable.CustomMessage));
                            loginFailedMessage.SetContentUrl("");
                            loginFailedMessage.SetRedirectDomain("");
                            loginFailedMessage.SetUpdateUrl("");
                            loginFailedMessage.SetRemoveResourceFingerprintData("");
                            loginFailedMessage.SetSecondsUntilMaintenanceEnd(-1);
                            loginFailedMessage.SetShowContactSupportForBan(false);
                            loginFailedMessage.SetReason(
                                _languageFactory.TranslateTo("Проведите очистку данных приложения, пожалуйста!"));
                        }

                        SendMessage(loginFailedMessage);
                    }
                }
                catch
                {
                    // ignored.
                }

                break;
            }
            case 4:
            {
                accountModel = Databases.AccountDatabase.LoadAccount(piranhaMessage.GetAccountId());
                {
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.PlayTimeSeconds,
                        Convert.ToInt32(
                            accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure
                                .PlayTimeSeconds)) + 10);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.SessionCount,
                        Convert.ToInt32(accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(
                            AccountStructure
                                .SessionCount)) + 1);
                    accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.UserIsAuthed, true);
                }

                break;
            }
        }

        serverConnection!.SetAccountModel(accountModel);
        var allianceModel = Databases.AllianceDatabase.LoadAlliance(
            (long)accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.AllianceId));

        var loginOkMessage = new LoginOkMessage();
        {
            loginOkMessage.SetAccountId(Convert.ToInt64(accountModel
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AccountId)));
            loginOkMessage.SetHomeId(Convert.ToInt64(accountModel
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.HomeId)));
            loginOkMessage.SetPassToken(accountModel
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.PassToken).ToString()!);
            loginOkMessage.SetFacebookId("EE0");
            loginOkMessage.SetGamecenterId("Z");
            loginOkMessage.SetServerMajorVersion(Fingerprint.GetMinorVersion());
            loginOkMessage.SetServerBuild(Fingerprint.GetBuildVersion());
            loginOkMessage.SetContentVersion(Fingerprint.GetMajorVersion());
            loginOkMessage.SetServerEnvironment(GlobalStaticCloud.PragmaAndServerEnvironment!);
            loginOkMessage.SetSessionCount(Convert.ToInt32(
                accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.SessionCount)));
            loginOkMessage.SetPlayTimeSeconds(Convert.ToInt32(
                accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure
                    .PlayTimeSeconds)));
            loginOkMessage.SetDaysSinceStartedPlaying(
                Convert.ToInt32(
                    accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure
                        .PlayTimeSeconds)) / 60 / 60 / 24);
            loginOkMessage.SetServerTime($"{DateTime.Now:yyyy/MM/dd-(dddd) HH:mm:ss}");
            loginOkMessage.SetAccountCreatedDate(accountModel
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AccountCreatedDate)
                .ToString()!);
            loginOkMessage.SetStartupCooldownSeconds(60);
            loginOkMessage.SetLoginCountry(_languageFactory.GetTextCodeByLanguage().ToUpper());
            loginOkMessage.SetKunlunId("0f");
            loginOkMessage.SetTier(0);
            loginOkMessage.SetSecondsUntilAccountDeletion(0);
        }

        var myAllianceMessage = new MyAllianceMessage();
        {
            myAllianceMessage.OnlineMembers = allianceModel == null!
                ? 0
                : ToOpenDictionaryHelper.ToAllianceMemberEntryDictionary(
                    allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                        .AllianceMemberEntryList)).Count(keyValuePair =>
                    IdentifierListener.GetV2LogicGameListenerByAccountId(keyValuePair.Key));

            myAllianceMessage.AllianceRole = allianceModel == null!
                ? 0
                : ((AllianceMemberEntry)accountModel
                    .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceMemberEntry))
                .AllianceRoleHelperTable;

            if (allianceModel == null!)
            {
                myAllianceMessage.AllianceHeaderEntry = null!;
            }
            else
            {
                var allianceHeaderEntry = new AllianceHeaderEntry();
                {
                    allianceHeaderEntry.SetAllianceId(allianceModel.GetAllianceId());
                    allianceHeaderEntry.SetAllianceName(allianceModel
                        .GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceName)
                        .ToString()!);
                    allianceHeaderEntry.SetScore(ToOpenDictionaryHelper.ToAllianceMemberEntryDictionary(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceMemberEntryList)).Sum(member =>
                        Convert.ToInt32(Databases.AccountDatabase.LoadAccount(member.Value!.AccountId)
                            .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.Trophies))));
                    allianceHeaderEntry.SetAllianceType(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceType)));
                    allianceHeaderEntry.SetAllianceBadgeData(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceBadgeData)));
                    allianceHeaderEntry.SetRequiredScore(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceRequiredScore)));
                    allianceHeaderEntry.SetPreferredLanguage(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceLanguage)));
                    allianceHeaderEntry.SetAllianceRegionData(Convert.ToInt32(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceRegion)));
                    allianceHeaderEntry.SetNumberOfMembers(ToOpenDictionaryHelper.ToAllianceMemberEntryDictionary(
                        allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceMemberEntryList)).Count);
                    allianceHeaderEntry.SetIsFamilyType(
                        (bool)allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure
                            .AllianceFamilyType));
                }

                myAllianceMessage.AllianceHeaderEntry = allianceHeaderEntry;
            }
        }

        SendMessage(loginOkMessage);
        SendMessage(new OwnHomeDataMessage(serverConnection!.GetAccountModel()));
        _lobbyInfoTimer = new System.Timers.Timer(30000);
        _lobbyInfoTimer.Elapsed += (_, _) =>
        {
            if (serverConnection?.GetAccountModel() == null) return;
            SendMessage(new LobbyInfoMessage(
                serverConnection.GetAccountModel(),
                0,
                InteractiveModule.ServerConnections?.Count ?? 0
            ));
        };
        _lobbyInfoTimer.AutoReset = true;
        _lobbyInfoTimer.Start();
        SendMessage(myAllianceMessage);


        // to set;

        _joinedTime = LogicTimeUtil.GetTimestamp();

        _logicHomeMode.AccountModel = serverConnection!.GetAccountModel();

        _logicHomeMode.SetGameListener(new LogicGameListener(connection!.GetUserListener()!, _logicHomeMode));
        _logicHomeMode.Home = serverConnection!.GetAccountModel().Home;
        _logicHomeMode.SetHome(null!);
        _logicHomeMode.SetHomeOwnerAvatar(null!);

        IdentifierListener.RemoveLogicGameListenerByAccountId(serverConnection!.GetAccountModel().GetAccountId());
        IdentifierListener.SetLogicGameListenerByAccountId(serverConnection!.GetAccountModel().GetAccountId(),
            _logicHomeMode.GetGameListener()!);

        _languageFactory = plIns switch
        {
            17 => LanguageFactory.Russian,
            0 => LanguageFactory.English,
            9 => LanguageFactory.German,
            13 => LanguageFactory.Chinese,
            _ => LanguageFactory.English
        };

        serverConnection!.GetAccountModel().SetFieldValueByAccountStructureParameterFromAccountModel(
            AccountStructure.LanguageLaserFactory, _languageFactory);

        if ((long)serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId) <= 0) return 1;

        ToSendAutomizeHelper.SendMyAlliance(this,
            Databases.AllianceDatabase.LoadAlliance((long)serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId)),
            serverConnection!.GetAccountModel(), true);

        ToSendAutomizeHelper.SendAllianceData(this,
            Databases.AllianceDatabase.LoadAlliance((long)serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId)),
            (long)serverConnection!.GetAccountModel()
                .GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AllianceId), true,
            serverConnection.GetAccountModel().GetAccountId());

        ToSendAutomizeHelper.SendAllianceStatus(
            Databases.AllianceDatabase.LoadAlliance(
                Convert.ToInt64(serverConnection!.GetAccountModel()
                    .GetFieldValueByAccountStructureParameterFromAccountModel(
                        AccountStructure.AllianceId))), serverConnection!.GetAccountModel().GetAccountId());
        return 1;
    }

    private int GetPlayerProfileMessageReceived(GetPlayerProfileMessage piranhaMessage)
    {
        var accountId = piranhaMessage.GetAccountId();
        try
        {
            var targetAccount = Databases.AccountDatabase.LoadAccount(accountId);
            if (targetAccount == null!) return 0;
            SendMessage(new PlayerProfileMessage(targetAccount));
            return 1;
        }
        catch { return 0; }
    }

    private int GetLeaderboardMessageReceived(GetLeaderboardMessage piranhaMessage)
    {
        var leaderboardType = piranhaMessage.GetLeaderboardType();
        try
        {
            var allAccounts = new List<AccountModel>();
            var maxId = Databases.AccountDatabase.GetMaxAccountId();
            for (long i = 1; i <= maxId; i++)
            {
                try
                {
                    var account = Databases.AccountDatabase.LoadAccount(i);
                    if (account != null!) allAccounts.Add(account);
                }
                catch { }
            }
            var sorted = allAccounts
                .OrderByDescending(a => (int)a.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.Trophies))
                .Take(200)
                .ToList();
            SendMessage(new LeaderboardMessage(sorted, leaderboardType));
            return 1;
        }
        catch
        {
            SendMessage(new LeaderboardMessage(new List<AccountModel>(), leaderboardType));
            return 0;
        }
    }
    
    private int AskForJoinableAlliancesListMessageReceived(AskForJoinableAlliancesListMessage piranhaMessage)
    {
        var response = new JoinableAllianceListMessage();
        
        var alliances = string.IsNullOrEmpty(piranhaMessage.SearchQuery)
            ? Databases.AllianceDatabase.GetRandomAllianceModels(99999)
            : Databases.AllianceDatabase.GetAllianceModelsByName(piranhaMessage.SearchQuery);
    
        foreach (var model in alliances.Take(20))
        {
            var entry = new AllianceHeaderEntry();
            entry.SetAllianceId((long)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceId));
            entry.SetAllianceName((string)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceName));
            entry.SetAllianceBadgeData((int)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceBadgeData));
            entry.SetAllianceType((int)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceType));
            entry.SetAllianceRegionData((int)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceRegion));
            entry.SetPreferredLanguage((int)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceLanguage));
            entry.SetRequiredScore((int)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceRequiredScore));
            entry.SetIsFamilyType((bool)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceFamilyType));
            
            var members = (Dictionary<long, AllianceMemberEntry?>?)model.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceMemberEntryList);
            entry.SetNumberOfMembers(members?.Count ?? 0);
            entry.SetScore(members?.Values.Sum(m => 
            {
                if (m == null) return 0;
                var acc = Databases.AccountDatabase.LoadAccount(m.AccountId);
                return Convert.ToInt32(acc.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.Trophies));
            }) ?? 0);
            
            response.AddAlliance(entry);
        }
    
        SendMessage(response);
        return 1;
    }

    private static string GenerateBindCode()
    {
        const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        var rng = new Random();
        return new string(Enumerable.Range(0, 8).Select(_ => chars[rng.Next(chars.Length)]).ToArray());
    }
    
    public int GetPlayerGeoEventSlot() => _playerGeoEventSlot;
}