using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicBrawlPassAutoCollectWarningSeenCommand : LogicCommand
    {
        public int WarningType;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            WarningType = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(WarningType);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 539;
        }
    }
