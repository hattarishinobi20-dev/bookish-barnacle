using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicBrawlPassUnlockedCommand : LogicCommand
    {
        public int PassTier;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteVInt(PassTier);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            PassTier = byteStream.ReadVInt();
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 219;
        }
    }
