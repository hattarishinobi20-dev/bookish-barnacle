using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicClaimAdRewardCommand : LogicCommand
    {
        public int AdType;
        public int AdRewardType;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            AdType = byteStream.ReadVInt();
            AdRewardType = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(AdType);
            byteStream.WriteVInt(AdRewardType);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 523;
        }
    }
