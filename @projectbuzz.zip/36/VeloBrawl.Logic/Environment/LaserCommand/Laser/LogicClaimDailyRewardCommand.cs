using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicClaimDailyRewardCommand : LogicCommand
    {
        public int Slot;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            Slot = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 503;
        }
    }
