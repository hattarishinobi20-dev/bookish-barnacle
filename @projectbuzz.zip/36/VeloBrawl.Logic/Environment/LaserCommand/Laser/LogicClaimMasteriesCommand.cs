using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicClaimMasteriesCommand : LogicCommand
{
    private int _tick1;
    private int _brawler;
    private int _masteryIndex;

    public override void Decode(ByteStream byteStream)
    {
        _tick1 = byteStream.ReadVInt();
        byteStream.ReadVInt();
        byteStream.ReadVInt();
        byteStream.ReadVInt();
        byteStream.ReadVInt();
        _brawler = byteStream.ReadVInt();
        _masteryIndex = byteStream.ReadVInt() - 1;
    }

    public override void Encode(ByteStream byteStream)
    {
        byteStream.WriteVInt(_tick1);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(_brawler);
        byteStream.WriteVInt(_masteryIndex + 1);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    public override int Execute(LogicHomeMode logicHomeMode) => 0;
    public override int GetCommandType() => 569;
}
