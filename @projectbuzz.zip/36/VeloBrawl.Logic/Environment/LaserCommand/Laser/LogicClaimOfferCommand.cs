using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Supercell.Titan.CommonUtils.Utils;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicClaimOfferCommand : LogicCommand
{
    private int _offerIndex;
    private int _unknown;

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        _offerIndex = byteStream.ReadVInt();
        _unknown = byteStream.ReadVInt();
    }

    public override void Encode(ByteStream byteStream)
    {
        base.Encode(byteStream);
        byteStream.WriteVInt(_offerIndex);
        byteStream.WriteVInt(_unknown);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode)
    {
        var accountModel = logicHomeMode.AccountModel;
        var offerList = (List<LogicOfferBundle>)accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(
            AccountStructure.LogicOfferBundleList);

        if (offerList == null || _offerIndex >= offerList.Count)
            return false;

        var offer = offerList[_offerIndex];
        if (offer == null)
            return false;

        if (offer.GetPurchased())
            return false;

        return true;
    }

    public override int Execute(LogicHomeMode logicHomeMode)
    {
        var accountModel = logicHomeMode.AccountModel;
        var avatar = logicHomeMode.Avatar;
        var offerList = (List<LogicOfferBundle>)accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(
            AccountStructure.LogicOfferBundleList);

        if (offerList == null || _offerIndex >= offerList.Count)
            return -1;

        var offer = offerList[_offerIndex];
        if (offer == null)
            return -1;

        try
        {
            var items = offer.GetItems();
            if (items == null || items.Count == 0)
                return -1;

            foreach (var item in items)
            {
                if (item == null)
                    continue;

                var itemType = item.GetItemType();
                var count = item.GetCount();

                switch (itemType)
                {
                    case ShopItemHelperTable.Gems:
                        avatar.AddDiamonds(count);
                        break;

                    case ShopItemHelperTable.Coin:
                        avatar.AddGold(count);
                        break;

                    case ShopItemHelperTable.StarPoints:
                        avatar.StarPoints += count;
                        break;
                }
            }

            offerList.RemoveAt(_offerIndex);
            accountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.LogicOfferBundleList,
                offerList
            );

            var listener = logicHomeMode.GetGameListener();
            if (listener != null)
                listener.Send(new OwnHomeDataMessage(accountModel));

            return 0;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[OFFER] ERROR: {ex.Message}");
            return -1;
        }
    }

    public override int GetCommandType()
    {
        return 519;
    }
}