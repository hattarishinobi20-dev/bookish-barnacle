using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using OfferBundle = VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser.LogicOfferBundle;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicClearShopTickersCommand : LogicCommand
    {
        public override int Execute(LogicHomeMode logicHomeMode)
        {
            OfferBundle[] bundles = logicHomeMode.Home.OfferBundles.ToArray();
            foreach (OfferBundle bundle in bundles)
            {
                bundle.SetPurchased(true);
            }

            return 0;
        }

        public override int GetCommandType()
        {
            return 515;
        }
    }
