using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicDiamondsAddedCommand : LogicCommand
    {
        public bool Unknown;
        public int Amount;
        public int Reason;
        public int Extra;
        public string? Message;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteBoolean(Unknown);
            byteStream.WriteInt(Amount);
            byteStream.WriteInt(Reason);
            byteStream.WriteInt(Extra);
            byteStream.WriteString(Message ?? string.Empty);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            Unknown = byteStream.ReadBoolean();
            Amount  = byteStream.ReadInt();
            Reason  = byteStream.ReadInt();
            Extra   = byteStream.ReadInt();
            Message = byteStream.ReadString(900000);
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 202;
        }
    }
