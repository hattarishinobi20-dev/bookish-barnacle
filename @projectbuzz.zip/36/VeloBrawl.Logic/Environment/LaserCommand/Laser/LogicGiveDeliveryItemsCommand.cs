using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicGiveDeliveryItemsCommand : LogicCommand
{
    public int GatchaBoxIndex;
    public List<DeliveryUnit> DeliveryUnits = new();
    public ForcedDrops? ForcedDrops;
    public int Param1;
    public int Param2;
    public int Param3;
    public bool Flag1;
    public bool Flag2;
    public int RewardTrackType;
    public int RewardForRank;
    public int BrawlPassSeason;

    public override void Encode(ByteStream byteStream)
    {
        byteStream.WriteVInt(GatchaBoxIndex);
        byteStream.WriteVInt(DeliveryUnits.Count);
        foreach (var unit in DeliveryUnits)
            unit.Encode(byteStream);
        byteStream.WriteBoolean(ForcedDrops != null);
        if (ForcedDrops != null)
            ForcedDrops.Encode(byteStream);
        byteStream.WriteVInt(Param1);
        byteStream.WriteVInt(Param2);
        byteStream.WriteVInt(Param3);
        byteStream.WriteBoolean(Flag1);
        byteStream.WriteBoolean(Flag2);
        base.Encode(byteStream);
    }

    public override void Decode(ByteStream byteStream)
    {
        GatchaBoxIndex = byteStream.ReadVInt();
        int count = byteStream.ReadVInt();
        for (int i = 0; i < count; i++)
            DeliveryUnits.Add(new DeliveryUnit(byteStream));
        if (byteStream.ReadBoolean())
            ForcedDrops = new ForcedDrops(byteStream);
        Param1 = byteStream.ReadVInt();
        Param2 = byteStream.ReadVInt();
        Param3 = byteStream.ReadVInt();
        Flag1  = byteStream.ReadBoolean();
        Flag2  = byteStream.ReadBoolean();
    }

    public override int Execute(LogicHomeMode logicHomeMode) => 0;

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    
    public override int GetCommandType() => 203;
}
