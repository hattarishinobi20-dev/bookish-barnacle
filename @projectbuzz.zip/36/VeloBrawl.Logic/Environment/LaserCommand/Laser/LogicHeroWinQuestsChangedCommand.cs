using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicHeroWinQuestsChangedCommand : LogicCommand
{
    public Quests? Quests { get; set; }

    public override void Encode(ByteStream byteStream)
    {
        if (byteStream.WriteBoolean(Quests != null))
            Quests!.Encode(byteStream);

        byteStream.WriteVInt(0);
        base.Encode(byteStream);
    }

    public override int Execute(LogicHomeMode logicHomeMode) => 0;

    public override int GetCommandType() => 220;
}
