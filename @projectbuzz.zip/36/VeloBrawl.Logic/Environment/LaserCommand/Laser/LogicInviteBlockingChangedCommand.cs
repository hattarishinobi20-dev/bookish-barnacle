using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicInviteBlockingChangedCommand : LogicCommand
    {
        public bool State;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteBoolean(State);
            base.Encode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 213;
        }
    }
