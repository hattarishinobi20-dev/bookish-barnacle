using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicPurchaseBrawlPassProgressCommand : LogicCommand
    {
        public int Unknown { get; set; }

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            Unknown = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return -1;
        }

        public override int GetCommandType()
        {
            return 536;
        }
    }
