using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicPurchaseDoubleCoinsCommand : LogicCommand
    {
        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 509;
        }
    }
