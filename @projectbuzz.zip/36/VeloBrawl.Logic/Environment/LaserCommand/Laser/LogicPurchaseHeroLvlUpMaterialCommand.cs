using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicPurchaseHeroLvlUpMaterialCommand : LogicCommand
    {
        public int PackIndex;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            PackIndex = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            if (PackIndex < 0 || PackIndex > ClientHome.GoldPacksAmount.Length) return -1;

            if (!logicHomeMode.Avatar.UseDiamonds(ClientHome.GoldPacksPrice[PackIndex])) return -2;

            logicHomeMode.Avatar.AddGold(ClientHome.GoldPacksAmount[PackIndex]);

            return 0;
        }

        public override int GetCommandType()
        {
            return 521;
        }
    }
