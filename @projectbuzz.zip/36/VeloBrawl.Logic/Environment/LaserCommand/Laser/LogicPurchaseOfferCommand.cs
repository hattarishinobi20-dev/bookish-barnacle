using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicPurchaseOfferCommand : LogicCommand
    {
        public int OfferIndex;
        public int Unknown;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);

            OfferIndex = byteStream.ReadVInt();
            Unknown = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            if (!CanExecute(logicHomeMode)) return -1;

            logicHomeMode.Home.PurchaseOffer(OfferIndex);

            return 0;
        }

        public override int GetCommandType()
        {
            return 519;
        }
    }
