using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicQuestsSeenCommand : LogicCommand
    {
        public override int Execute(LogicHomeMode logicHomeMode)
        {
            foreach (Quest quest in logicHomeMode.Home.Quests.QuestList.ToArray())
            {
                quest.QuestSeen = true;
            }

            return 0;
        }

        public override int GetCommandType()
        {
            return 533;
        }
    }
