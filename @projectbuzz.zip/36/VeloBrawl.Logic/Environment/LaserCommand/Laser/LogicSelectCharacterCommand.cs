using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSelectCharacterCommand : LogicCommand
    {
        public int CharacterInstanceId;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            byteStream.ReadVInt();
            CharacterInstanceId = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            int globalId = GlobalId.CreateGlobalId(16, CharacterInstanceId);
            if (logicHomeMode.Avatar.HasHero(globalId))
            {
                logicHomeMode.Home.CharacterId = globalId;
                logicHomeMode.CharacterChanged.Invoke(globalId);
                return 0;
            }

            return -1;
        }

        public override int GetCommandType()
        {
            return 525;
        }
    }
