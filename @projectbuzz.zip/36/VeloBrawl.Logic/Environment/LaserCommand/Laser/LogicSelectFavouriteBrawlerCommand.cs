using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicSelectFavouriteBrawlerCommand : LogicCommand
{
    private int _characterId;
    private int _characterHigh;

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        _characterHigh = byteStream.ReadVInt();
        _characterId = byteStream.ReadVInt();
    }

    public override void Encode(ByteStream byteStream)
    {
        base.Encode(byteStream);
        byteStream.WriteVInt(_characterHigh);
        byteStream.WriteVInt(_characterId);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    public override int Execute(LogicHomeMode logicHomeMode) => 0;
    public override int GetCommandType() => 570;
}
