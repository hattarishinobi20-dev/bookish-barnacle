using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Supercell.Titan.CommonUtils.Utils;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSetPlayerNameColorCommand : LogicCommand
    {
        public int NameColorInstanceId;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            byteStream.ReadVInt();
            NameColorInstanceId = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            if (NameColorInstanceId < 0) return -1;
        
            int globalId = GlobalId.CreateGlobalId(CsvHelperTable.NameColors.GetId(), NameColorInstanceId);
            logicHomeMode.Home.NameColorId = globalId;
            logicHomeMode.AccountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.NameColorGlobalId, globalId);
            return 0;
        }
        
        public override bool CanExecute(LogicHomeMode logicHomeMode) => true;

        public override int GetCommandType()
        {
            return 527;
        }
    }
