using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSetSupportedCreatorCommand : LogicCommand
    {
        public string? CreatorTag;

        public override void Encode(ByteStream byteStream)
        {
            bool hasCreator = CreatorTag != null;
            byteStream.WriteBoolean(hasCreator);
            if (hasCreator)
                byteStream.WriteString(CreatorTag!);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            if (byteStream.ReadBoolean())
                CreatorTag = byteStream.ReadString(900000);
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 215;
        }
    }
