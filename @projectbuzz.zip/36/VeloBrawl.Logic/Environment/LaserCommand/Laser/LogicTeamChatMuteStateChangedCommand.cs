using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicTeamChatMuteStateChangedCommand : LogicCommand
    {
        public bool IsMuted;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteBoolean(IsMuted);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            IsMuted = byteStream.ReadBoolean();
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 221;
        }
    }
