using VeloBrawl.Supercell.Titan.CommonUtils;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_11;

public class AskForJoinableAlliancesListMessage : PiranhaMessage
{
    public string SearchQuery = string.Empty;

    public AskForJoinableAlliancesListMessage()
    {
        Helper.Skip();
    }

    public override void Decode()
    {
        base.Decode();
        SearchQuery = ByteStream.ReadString(900000);
    }

    public override int GetMessageType() => 14303;
    public override int GetServiceNodeType() => 11;
}
