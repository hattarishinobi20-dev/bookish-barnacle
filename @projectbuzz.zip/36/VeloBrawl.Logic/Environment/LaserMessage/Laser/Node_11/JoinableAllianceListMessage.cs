using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Alliance;
using VeloBrawl.Supercell.Titan.CommonUtils;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_11;

public class JoinableAllianceListMessage : PiranhaMessage
{
    private readonly List<AllianceHeaderEntry> _alliances = new();

    public JoinableAllianceListMessage()
    {
        Helper.Skip();
    }

    public void AddAlliance(AllianceHeaderEntry entry) => _alliances.Add(entry);

    public override void Encode()
    {
        base.Encode();
        ByteStream.WriteVInt(_alliances.Count);
        foreach (var alliance in _alliances)
            alliance.Encode(ByteStream);
    }

    public override int GetMessageType() => 24304;
    public override int GetServiceNodeType() => 11;
}
