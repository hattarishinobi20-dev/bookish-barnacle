using VeloBrawl.Titan.DataStream.Helps;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class AskForBattleEndMessage : PiranhaMessage
{
    public int BattleResult;
    public int Rank;
    public int LocationId;

    public override void Decode()
    {
        base.Decode();
        BattleResult = ByteStream.ReadVInt();
        ByteStream.ReadVInt();
        Rank         = ByteStream.ReadVInt();
        LocationId   = ByteStreamHelper.ReadDataReference(ByteStream);
        var count    = ByteStream.ReadVInt();
        for (var i = 0; i < count; i++)
        {
            ByteStream.ReadLong();
            ByteStream.ReadVInt();
            ByteStream.ReadVInt();
            ByteStream.ReadVInt();
            ByteStream.ReadInt();
            ByteStreamHelper.ReadDataReference(ByteStream);
            ByteStreamHelper.ReadDataReference(ByteStream);
            ByteStream.ReadBoolean();
            ByteStream.ReadBoolean();
            ByteStream.ReadString(128);
            ByteStream.ReadVInt();
            ByteStream.ReadVInt();
            ByteStream.ReadVInt();
            ByteStream.ReadVInt();
            ByteStream.ReadBoolean();
        }
    }

    public override int GetMessageType() => 14110;
    public override int GetServiceNodeType() => 9;
}
