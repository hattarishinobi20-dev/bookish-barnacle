using VeloBrawl.Supercell.Titan.CommonUtils;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class AvatarNameCheckRequestMessage : PiranhaMessage
{
    private string _name = string.Empty;

    public AvatarNameCheckRequestMessage()
    {
        Helper.Skip();
    }

    public override void Decode()
    {
        base.Decode();
        _name = ByteStream.ReadString(900000);
    }

    public string GetName() => _name;

    public override int GetMessageType() => 14600;
    public override int GetServiceNodeType() => 9;
}