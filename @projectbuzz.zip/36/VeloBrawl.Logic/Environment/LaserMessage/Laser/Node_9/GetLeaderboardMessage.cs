using VeloBrawl.Supercell.Titan.CommonUtils;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class GetLeaderboardMessage : PiranhaMessage
{
    private bool _isRegional;
    private int _leaderboardType;

    public GetLeaderboardMessage()
    {
        Helper.Skip();
    }

    public override void Decode()
    {
        base.Decode();
        _isRegional = ByteStream.ReadBoolean();
        _leaderboardType = ByteStream.ReadVInt();
    }

    public bool GetIsRegional()
    {
        return _isRegional;
    }

    public int GetLeaderboardType()
    {
        return _leaderboardType;
    }

    public override int GetMessageType()
    {
        return 14403;
    }

    public override int GetServiceNodeType()
    {
        return 9;
    }
}