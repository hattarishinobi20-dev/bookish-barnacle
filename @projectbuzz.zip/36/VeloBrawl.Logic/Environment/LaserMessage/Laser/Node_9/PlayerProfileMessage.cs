using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Supercell.Titan.CommonUtils;
using VeloBrawl.Supercell.Titan.CommonUtils.Utils;
using VeloBrawl.Titan.DataStream.Helps;
using VeloBrawl.Titan.Mathematical.Data;
using VeloBrawl.Tools.LaserCsv;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class PlayerProfileMessage : PiranhaMessage
{
    private AccountModel? _accountModel;

    public PlayerProfileMessage() { Helper.Skip(); }

    public PlayerProfileMessage(AccountModel accountModel)
    {
        _accountModel = accountModel;
    }

    public override void Encode()
    {
        base.Encode();

        if (_accountModel == null)
        {
            ByteStream.WriteVInt(0);
            ByteStream.WriteVInt(0);
            return;
        }

        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt((int)_accountModel.GetAccountId());
        ByteStream.WriteBoolean(false);

        var heroes = _accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.Heroes) as List<int> ?? new List<int>();

        ByteStream.WriteVInt(heroes.Count);
        foreach (var heroId in heroes)
        {
            ByteStreamHelper.WriteDataReference(ByteStream, GlobalId.CreateGlobalId(CsvHelperTable.Characters.GetId(), heroId));
            ByteStream.WriteVInt(0); // сила прокачки
            ByteStream.WriteVInt(0); // кубки бойца
            ByteStream.WriteVInt(0); // макс кубки бойца
            ByteStream.WriteVInt(1); // уровень силы (1 = обычно типа окак)
        }

        ByteStream.WriteVInt(3);

        ByteStream.WriteVInt(4);
        ByteStream.WriteVInt((int)_accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.Trophies));

        ByteStream.WriteVInt(3);
        ByteStream.WriteVInt((int)_accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.MaxTrophies));

        ByteStream.WriteVInt(7);
        ByteStream.WriteVInt((int)_accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.PlayerThumbnailGlobalId));

        ByteStream.WriteString(_accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AvatarName).ToString());
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt((int)_accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.PlayerThumbnailGlobalId));
        ByteStream.WriteVInt((int)_accountModel.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.NameColorGlobalId));
        ByteStream.WriteVInt(0);

        ByteStream.WriteBoolean(false);
    }

    public void SetAccountModel(AccountModel accountModel) { _accountModel = accountModel; }

    public override int GetMessageType() => 24113;
    public override int GetServiceNodeType() => 9;
}