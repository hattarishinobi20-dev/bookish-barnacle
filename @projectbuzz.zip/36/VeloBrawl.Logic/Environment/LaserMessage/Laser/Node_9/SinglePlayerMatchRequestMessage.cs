using VeloBrawl.Titan.DataStream.Helps;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class SinglePlayerMatchRequestMessage : PiranhaMessage
{
    public int CharacterId;
    public int SkinId;

    public override void Decode()
    {
        base.Decode();
        CharacterId = ByteStreamHelper.ReadDataReference(ByteStream);
        SkinId      = ByteStreamHelper.ReadDataReference(ByteStream);
    }

    public override int GetMessageType() => 14118;
    public override int GetServiceNodeType() => 9;
}
