using Newtonsoft.Json;
using System.Numerics;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home;

[JsonObject(MemberSerialization.OptIn)]
public class ClientHome
{
    public static readonly int[] GoldPacksPrice  = { 20, 50, 140, 280 };
    public static readonly int[] GoldPacksAmount = { 150, 400, 1200, 2600 };

    [JsonProperty] public long HomeId;
    [JsonProperty] public int ThumbnailId;
    [JsonProperty] public int NameColorId;
    [JsonProperty] public int CharacterId;

    [JsonProperty] public int BrawlPassProgress  = 1;
    [JsonProperty] public int PremiumPassProgress = 1;
    [JsonProperty] public int BrawlPassTokens;
    [JsonProperty] public bool HasPremiumPass;

    [JsonProperty] public List<int> UnlockedEmotes  = new();
    [JsonProperty] public List<int> UnlockedSkins   = new();
    [JsonProperty] public List<LogicOfferBundle> OfferBundles = new();

    [JsonProperty] public int TrophyRoadProgress = 1;
    [JsonProperty] public Quests? Quests;
    [JsonProperty] public int TokenDoublers;
    [JsonProperty] public int TokenReward;

    public ClientHome()
    {
        CharacterId = GlobalId.CreateGlobalId(16, 0);
    }

    public void PurchaseOffer(int index)
    {
        if (index >= 0 && index < OfferBundles.Count)
            OfferBundles.RemoveAt(index);
    }
}
