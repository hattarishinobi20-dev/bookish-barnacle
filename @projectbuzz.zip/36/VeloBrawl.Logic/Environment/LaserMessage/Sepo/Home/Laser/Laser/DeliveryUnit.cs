using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

public class DeliveryUnit
{
    public readonly int Type;
    private readonly List<GatchaDrop> _drops = new();

    public DeliveryUnit(int type) { Type = type; }

    public DeliveryUnit(ByteStream stream)
    {
        Type = stream.ReadVInt();
        int count = stream.ReadVInt();
        for (int i = 0; i < count; i++)
            _drops.Add(new GatchaDrop(stream));
    }

    public void AddDrop(GatchaDrop drop) { if (drop != null) _drops.Add(drop); }
    public GatchaDrop[] GetDrops() => _drops.ToArray();

    public void Encode(ByteStream stream)
    {
        stream.WriteVInt(Type);
        stream.WriteVInt(_drops.Count);
        foreach (var drop in _drops)
            drop.Encode(stream);
    }
}
