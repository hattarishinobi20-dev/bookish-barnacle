using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.DataStream.Helps;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

public class GatchaDrop
{
    public int Count;
    public int DataGlobalId;
    public int SkinGlobalId;
    public int CardGlobalId;
    public int PinGlobalId;
    public int Type;
    public bool IsExecuted;

    public GatchaDrop(int type) { Type = type; }

    public GatchaDrop(ByteStream stream)
    {
        Count        = stream.ReadVInt();
        DataGlobalId = ByteStreamHelper.ReadDataReference(stream);
        Type         = stream.ReadVInt();
        SkinGlobalId = ByteStreamHelper.ReadDataReference(stream);
        PinGlobalId  = ByteStreamHelper.ReadDataReference(stream);
        CardGlobalId = ByteStreamHelper.ReadDataReference(stream);
        stream.ReadVInt();
        stream.ReadVInt();
    }

    public void Encode(ByteStream stream)
    {
        stream.WriteVInt(Count);
        ByteStreamHelper.WriteDataReference(stream, DataGlobalId);
        stream.WriteVInt(Type);
        ByteStreamHelper.WriteDataReference(stream, SkinGlobalId);
        ByteStreamHelper.WriteDataReference(stream, PinGlobalId);
        ByteStreamHelper.WriteDataReference(stream, CardGlobalId);
        stream.WriteVInt(0);
        stream.WriteVInt(0);
    }
}
