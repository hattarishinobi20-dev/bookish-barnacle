using Newtonsoft.Json;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

[JsonObject(MemberSerialization.OptIn)]
public class Quests
{
    private static readonly int[] AllowedModes = { 0, 2, 5, 6, 9, 11 };

    [JsonProperty("quest_list")]
    public List<Quest> QuestList = new();

    public void AddRandomQuests(List<Hero> unlockedHeroes, int count)
    {
        var characters = unlockedHeroes.Select(x => x.CharacterId).ToList();
        if (characters.Count == 0) return;
        var rand = new Random();
        AddQuest(rand, characters, false, 3, 100, true);
        AddQuest(rand, characters, false, 3, 100, true);
        AddQuest(rand, characters, false, 6, 250, false);
        AddQuest(rand, characters, false, 6, 250, false);
        AddQuest(rand, characters, false, 10, 500, false);
        AddQuest(rand, characters, true,  10, 500, false);
    }

    private void AddQuest(Random rand, List<int> characters, bool isPremium, int goal, int reward, bool isDaily)
    {
        var quest = new Quest { MissionType = 1, Reward = reward, QuestGoal = goal, BrawlPassExclusive = isPremium, IsDailyQuest = isDaily };
        if (rand.Next(120) > 40)
            quest.CharacterId = characters[rand.Next(0, characters.Count)];
        else
            quest.GameModeVariation = AllowedModes[rand.Next(0, AllowedModes.Length)];
        QuestList.Add(quest);
    }

    public void Encode(ByteStream byteStream)
    {
        byteStream.WriteVInt(QuestList.Count);
        foreach (var quest in QuestList.ToArray())
            quest.Encode(byteStream);
    }
}
