﻿using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Logic.Dynamic;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Event;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser;

public class LogicConfData(AccountModel accountModel)
{
    public List<IntValueEntry> v1 = new List<IntValueEntry>();

    public void Home()
    {
        v1.Add(new(1, GlobalId.CreateGlobalId(41, 25))); // фон
        v1.Add(new(10046, 1)); // не понял сам но спиздил с бсл41 зато ворк

    public void Encode(ByteStream byteStream)
    {
        Home();

        int[] v2 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 20, 21, 22, 23, 24]; // слоты

        byteStream.WriteVInt(0);

        byteStream.WriteVInt(v2.Length); // количество слотов
        {
            foreach (var x in v2) new EventSlot(x).Encode(byteStream);
        }

        byteStream.WriteVInt(DynamicServerParameters.Event1DataMassive.Count); // неважно 
            foreach (var variable in DynamicServerParameters.Event1DataMassive) variable.Value.Encode(byteStream);
        }

        byteStream.WriteVInt(DynamicServerParameters.Event2DataMassive.Count); // неважно х2
        {
            foreach (var variable in DynamicServerParameters.Event2DataMassive) variable.Value.Encode(byteStream);
        }

        var v101 = byteStream.WriteVInt(1); // unknown list
        {
            for (var i = 0; i < v101; i++) byteStream.WriteVInt(i);
        }

        var v102 = byteStream.WriteVInt(0); // unknown list
        {
            for (var i = 0; i < v102; i++) byteStream.WriteVInt(i);
        }

        var v103 = byteStream.WriteVInt(0); // unknown list
        {
            for (var i = 0; i < v103; i++) byteStream.WriteVInt(i);
        }

        byteStream.WriteBoolean(false); // отказано 

        var v104 = byteStream.WriteVInt(0); // ReleaseEntry 
        {
            for (var i = 0; i < v104; i++) new ReleaseEntry().Encode(byteStream);
        }

        byteStream.WriteVInt(v1.Count); // IntValueEntry фон
        {
            foreach (var a1 in v1)
            {
                a1.Encode(byteStream);
            }
        }

        var v105 = byteStream.WriteVInt(0); // TimedIntValueEntry 
        {
            for (var i = 0; i < v105; i++) new TimedIntValueEntry().Encode(byteStream);
        }

        var v106 = byteStream.WriteVInt(0); // CustomEvent 
        {
            for (var i = 0; i < v106; i++) new CustomEvent().Encode(byteStream);
        }
    }
}