using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Logic.Environment.LaserCommand;
using VeloBrawl.Logic.Environment.LaserListener;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Avatar;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;

public class LogicHomeMode
{
    private LogicClientAvatar _logicClientAvatar = null!;
    private LogicClientHome   _logicClientHome   = null!;
    private LogicGameListener? _logicGameListener;

    public AccountModel AccountModel { get; set; } = null!;

    public ClientAvatar Avatar    { get; set; } = new();
    public ClientHome   Home      { get; set; } = new();
    public LogicGameListener? GameListener => _logicGameListener;

    public Action<int> CharacterChanged { get; set; } = _ => { };

    public void SimulateGatcha(DeliveryUnit unit)
    {
        var rand = new Random();
        unit.AddDrop(new GatchaDrop(7) { Count = 20 + rand.Next(0, 60) });
    }

    public void EndClientTurnReceived(int tick, int checksum, IEnumerable<LogicCommand> commands,
        LogicGameListener? logicGameListener = null)
    {
        logicGameListener ??= _logicGameListener;
        commands = commands.Where(command => command.CanExecute(this));

        foreach (var command in commands)
        {
            int result = command.Execute(this);
            if (result != 0)
            {
                if (command.GetCommandType() == 517 && result == -6)
                    continue;
            
                Console.WriteLine($"[OOSYNC] Command {command.GetCommandType()} returned {result}");
                logicGameListener!.Send(new OutOfSyncMessage());
            }
        }
    }
    
    public LogicGameListener? GetGameListener() => _logicGameListener;
    public void SetGameListener(LogicGameListener? logicGameListener) => _logicGameListener = logicGameListener;

    public LogicClientHome GetHome() => _logicClientHome;
    public void SetHome(LogicClientHome logicClientHome) => _logicClientHome = logicClientHome;

    public LogicClientAvatar GetPlayerAvatar() => _logicClientAvatar;
    public void SetHomeOwnerAvatar(LogicClientAvatar logicClientAvatar) => _logicClientAvatar = logicClientAvatar;
}
