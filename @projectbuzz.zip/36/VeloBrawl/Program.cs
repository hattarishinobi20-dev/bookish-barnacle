﻿using System.Text;
using VeloBrawl.Bot;
using VeloBrawl.Init;
using VeloBrawl.Manage.Laser;

namespace VeloBrawl;

public abstract class Program : Initializer
{
    public static void Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        DrawLogo();

        Custom.Stream.Program.Main(args);
        General.Program.Main(args);
        Logic.Program.Main(args);
        Manage.Program.Main(args);
        Proxy.Program.Main(args);
        Service.Program.Main(args);
        StaticService.Program.Main(args);
        Supercell.Titan.Program.Main(args);
        Titan.Program.Main(args);
        Tools.Program.Main(args);

        var loader = new Loader();
        {
            Start();

            var botConfig = BotConfig.LoadFromFile("SaveBase/bot_config.json");
            VeloBrawl.Logic.Bot.BotBridge.BotUsername = botConfig.BotUsername;
            TelegramBotService.Start(botConfig);

            loader.SetParameters("150.241.70.176", [9449], [9339]);
            loader.LoadNet();
            loader.ManageNet();
            loader.ManageDb();
            loader.ManageTools();
        }
    }

    private static void DrawLogo()
    {
        const string logoText = """
                                ██╗░░░██╗███████╗██╗░░░░░░█████╗░  ██████╗░██████╗░░█████╗░░██╗░░░░░░░██╗██╗░░░░░
                                ██║░░░██║██╔════╝██║░░░░░██╔══██╗  ██╔══██╗██╔══██╗██╔══██╗░██║░░██╗░░██║██║░░░░░
                                ╚██╗░██╔╝█████╗░░██║░░░░░██║░░██║  ██████╦╝██████╔╝███████║░╚██╗████╗██╔╝██║░░░░░
                                ░╚████╔╝░██╔══╝░░██║░░░░░██║░░██║  ██╔══██╗██╔══██╗██╔══██║░░████╔═████║░██║░░░░░
                                ░░╚██╔╝░░███████╗███████╗╚█████╔╝  ██████╦╝██║░░██║██║░░██║░░╚██╔╝░╚██╔╝░███████╗
                                ░░░╚═╝░░░╚══════╝╚══════╝░╚════╝░  ╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░░╚══════╝
                                """;

        var lines = logoText.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        var longestLineLength = lines.Select(line => line.Length).Prepend(0).Max();

        foreach (var line in lines) Console.WriteLine(line.PadLeft(longestLineLength - line.Length / 10 + line.Length));
    }
}